const seedJobs = require('./seeders/jobSeeder');
const { seedApplications, seedSavedJobs, undoSeeding } = require('./seeders/applicationSeeder');

const seedDatabase = async () => {
  try {
    // First seed jobs
    await seedJobs();
    
    // Then seed applications and saved jobs
    await seedApplications();
    await seedSavedJobs();
    
    console.log('Database seeding completed successfully');
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

// Check if --undo flag is provided
if (process.argv.includes('--undo')) {
  undoSeeding()
    .then(() => {
      console.log('Database seeding undone successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Error undoing database seeding:', error);
      process.exit(1);
    });
} else {
  seedDatabase();
} 